import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarHeader,
} from "@/components/ui/sidebar"

import logoLight from "@/assets/LogoHorizontalLight.webp"
import logoDark from "@/assets/LogoHorizontalDark.webp"

export default function AppSidebar() {
  return (
    <Sidebar className="border-none **:data-[sidebar=sidebar]:bg-background">
      <SidebarHeader className="flex h-14.5 w-full items-center justify-center border-b dark:border-b-neutral-700">
        <img
          src={logoDark}
          alt="Readmeo Logo"
          className="hidden w-32 dark:block"
        />
        <img
          src={logoLight}
          alt="Readmeo Logo"
          className="block w-32 dark:hidden"
        />
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup />
        <SidebarGroup />
      </SidebarContent>
      <SidebarFooter />
    </Sidebar>
  )
}
