export default function TopNavbar() {
  return (
    <nav className="w-full h-14.5 bg-background border-b dark:border-b-neutral-700"></nav>
  )
}
